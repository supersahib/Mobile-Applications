//
//  PlaySoundsViewController.swift
//  Voice Changer
//
//  Created by Sahib Singh on 1/22/16.
//  Copyright (c) 2016 Sahib Singh. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController {

//  Declarations
    var audioPlayer: AVAudioPlayer!
    var receivedAudio:RecordedAudio! //object of class we created
    var audioEngine: AVAudioEngine! //allows us to manipulate audio
    var audioFile: AVAudioFile!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        audioPlayer = try? AVAudioPlayer(contentsOfURL: receivedAudio.filePathURL)
        audioPlayer.enableRate = true
        audioEngine = AVAudioEngine()
        audioFile = try! AVAudioFile(forReading: receivedAudio.filePathURL)
    }

    
/* ------------------- IBActions (buttons) ------------------------- */
    
    //action for play button (regular playback)
    @IBAction func playSoundRegularly(sender: UIButton) {
        resetAudioPlayer(1.0)
        audioPlayer.play()
    }
    
    //action for stop button
    @IBAction func stopSound(sender: UIButton) {
        resetAudioPlayer(1.0)
    }
    
    //action for slow playback button (snail)
    @IBAction func playSlowSound(sender: UIButton) {
        resetAudioPlayer(0.5)
        audioPlayer.play()
    }

    //action for fast playback button (bunny)
    @IBAction func playSoundFast(sender: UIButton) {
        resetAudioPlayer(2.0)
        audioPlayer.play()
    }
    
    //action for high-pitched playback button (chipmunk)
    @IBAction func playHighPitched(sender: UIButton) {
        playAudioAtPitch(1000);

    }
    
    //action for low-pitched playback button (darth vader)
    @IBAction func playLowPitched(sender: UIButton) {
        playAudioAtPitch(-1000)
    }
    
    
/* -----------------   Helper methods ------------------------------ */
    
    //had some repeated code, so made a new function to reset time and set a new rate
    func resetAudioPlayer(newRate: Float){
        audioPlayer.stop()
        audioEngine.stop()
        audioPlayer.currentTime = 0.0
        audioPlayer.rate = newRate
    }
    
    
    //new function that plays audio with variable pitch (argument is float from -2400 to 2400)
    func playAudioAtPitch(pitch: Float){
        audioPlayer.stop()
        audioEngine.stop()
        audioEngine.reset()
        
        let audioPlayerNode = AVAudioPlayerNode()
        audioEngine.attachNode(audioPlayerNode)
        
        let changePitchEffect = AVAudioUnitTimePitch()
        changePitchEffect.pitch = pitch
        audioEngine.attachNode(changePitchEffect)
        
        audioEngine.connect(audioPlayerNode, to: changePitchEffect, format: nil)
        audioEngine.connect(changePitchEffect, to: audioEngine.outputNode, format: nil)
        
        audioPlayerNode.scheduleFile(audioFile, atTime: nil, completionHandler: nil)
        try! audioEngine.start()
        
        audioPlayerNode.play()
        
    }
}
