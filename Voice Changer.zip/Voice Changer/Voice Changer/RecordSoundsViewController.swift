//
//  RecordSoundsViewController.swift
//  Voice Changer
//
//  Created by Sahib Singh on 1/17/16.
//  Copyright (c) 2016 Sahib Singh. All rights reserved.
//

import UIKit
import AVFoundation

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {

//  declarations
    
    @IBOutlet weak var recordingInProgress: UILabel!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var microphoneButton: UIButton!
    var audioRecorder:AVAudioRecorder!
    var recordedAudio:RecordedAudio!    //RecordedAudio object
    
    //before screen appears
    override func viewWillAppear(animated: Bool) {
        stopButton.hidden = true        //hide stop button
        microphoneButton.enabled = true   //enable the microphone button to be touched
        recordingInProgress.text = "Tap to Record"
    }

/* ------------------- IBActions (buttons) ------------------------- */
    //action for record button
    @IBAction func Record(sender: UIButton) {
        recordingInProgress.text = "Recording"
        stopButton.hidden = false;              //show the stop button
        microphoneButton.enabled = false;       //disable the microphone button (cannot be "clicked" or touched)
        
        //helps us get filepath or location of our audio
        let dirPath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0] //getting path to DocumentDirectory within our app (permitted to store files here)
        
        let recordingName = "my_audio.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = NSURL.fileURLWithPathComponents(pathArray)
        
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(AVAudioSessionCategoryPlayAndRecord)
        } catch _ {
        }
        
        //initialize and prepare audio recorder
        audioRecorder = try? AVAudioRecorder(URL: filePath!, settings: [:])
        
        //audioRecorder's delegate is this class, now we can implement all of the AVAudioRecorderDelegate methods
        audioRecorder.delegate = self
        audioRecorder.meteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    //action for stopRecording button
    @IBAction func stopRecording(sender: UIButton) {
        audioRecorder.stop()
        
        //deactivate audio session
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setActive(false)
        } catch _ {
        } //Set the audio session category and mode in order to communicate to the system how you intend to use audio in your app
    }
    
/*------------------------------------------------------------------ */
    
    //inherited from UIViewController
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {
        //if recording was finished successfully
        if(flag){
            //save recorded audio, initialize RecordedAudio
            recordedAudio = RecordedAudio(filePathUrl: recorder.url, newTitle: recorder.url.lastPathComponent!)

            //move to next scene (perform segue)
            performSegueWithIdentifier("stopRecording", sender: recordedAudio) //inherited from UIViewController, first parameter is the EXACT name of the segue, second parameter is the object sent
            
        }
        else{
            print("Recording was not successful")
            microphoneButton.enabled = true
            stopButton.hidden = true
        }
    }
    
    //inherited (UIViewController). Gets called before a segue is about to be performed. great place to pass any data
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        //checks if segue is the one we want
        if(segue.identifier == "stopRecording"){
            //passing data
            let playSoundsVC:PlaySoundsViewController = segue.destinationViewController as! PlaySoundsViewController
            
            //sender is the object that initiated the segue
            let data = sender as! RecordedAudio
            
            //passing the data
            playSoundsVC.receivedAudio = data
        }
    }
}

