//
//  RecordedAudio.swift
//  Voice Changer
//
//  Created by Sahib Singh on 1/22/16.
//  Copyright (c) 2016 Sahib Singh. All rights reserved.
//

import Foundation

//this class is our Model of our app (MVC)
class RecordedAudio{
    var filePathURL: NSURL!
    var title: String!
    
    
    init(filePathUrl: NSURL, newTitle: String) {
        filePathURL = filePathUrl
        title = newTitle
    }

}